#ifndef __CAN__RECV__
#define __CAN__RECV__
#include "can_send_recv.h"

int can_recv_main(int argc, char *argv[],Ui::can_send_recv *ui);
#endif
