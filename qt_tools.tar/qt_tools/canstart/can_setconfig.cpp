#include "can_setconfig.h"
#include "ui_can_config.h"
#include "canconfig.h"
#include <string.h>
#include <QStringList>
#include <QString>
#define CANCONFIG 1

can_config::can_config(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::can_config)
{
    ui->setupUi(this);
    char *opt = (char *)ui->canconfig_opt->currentText().toStdString().c_str();

    if(strcmp(opt,"customcommand") != 0)
    {
        ui->can_lable_cmd->hide();
        ui->can_con_cmd->hide();
    }
    connect(ui->canconfig_opt,&QComboBox::currentTextChanged,this,&can_config::hide_show);
}

can_config::~can_config()
{
    delete ui;
}

void can_config::on_canconfig_back_clicked()
{
    emit canconfig_sig(CANCONFIG);
}

void can_config::on_canconfig_ok_clicked()
{
    int argc  = 0;
    int i = 0;
    char *argv[10]={NULL};

    QString str;
    QStringList strList;
    char argv_buf[1024]={0};
    int buf_len = 0;


    char *opt = (char *)ui->canconfig_opt->currentText().toStdString().c_str();
    bzero(argv_buf,1024);

    if(strcmp(opt,"baudrate")==0)
    {
        argv[0] = "canconfig";
       // argv[1] = (char *)ui->can_file->text().toStdString().c_str();
        //argv[2] =(char *)ui->
        ui->canconfig_errmsg->append("The landlord is lazy, the function is not developed...Please select customcommand to deal with");
        return ;
    }else if(strcmp(opt,"setbitrate")==0)
    {

        argv[0] = "canconfig";
        //argv[1] = (char *)ui->can_file->text().toStdString().c_str();

        str = ui->can_file->text();
        strList= str.split(" ",QString::SkipEmptyParts);
        str = strList[0];
        strncpy(&argv_buf[buf_len],str.toStdString().c_str(),strlen(str.toStdString().c_str()));
        argv[1]=&argv_buf[buf_len];
        buf_len += strlen(str.toStdString().c_str());
        argv_buf[buf_len] = '\0';
        buf_len+=1;

        argv[2] = "bitrate";
       // argv[3] = (char *)ui->can_bitrate->text().toStdString().c_str();
        str = ui->can_bitrate->text();
        strList= str.split(" ",QString::SkipEmptyParts);
        str = strList[0];
        strncpy(&argv_buf[buf_len],str.toStdString().c_str(),strlen(str.toStdString().c_str()));
        argv[3]=&argv_buf[buf_len];
        buf_len += strlen(str.toStdString().c_str());
        argv_buf[buf_len] = '\0';
        buf_len+=1;

        argv[4] = NULL;
        argc = 4;
    }else if(strcmp(opt,"setbittiming")==0)
    {
        ui->canconfig_errmsg->append("The landlord is lazy, the function is not developed...Please select customcommand to deal with");
        return ;
    }else if(strcmp(opt,"ctrlmodeon")==0)
    {

        argv[0] = "canconfig";
       // argv[1] = (char *)ui->can_file->text().toStdString().c_str();
        str = ui->can_file->text();
        strList= str.split(" ",QString::SkipEmptyParts);
        str = strList[0];
        strncpy(&argv_buf[buf_len],str.toStdString().c_str(),strlen(str.toStdString().c_str()));
        argv[1]=&argv_buf[buf_len];
        buf_len += strlen(str.toStdString().c_str());
        argv_buf[buf_len] = '\0';
        buf_len+=1;

        argv[2] = "bitrate";
       // argv[3] = (char *)ui->can_bitrate->text().toStdString().c_str();
        str = ui->can_bitrate->text();
        strList= str.split(" ",QString::SkipEmptyParts);
        str = strList[0];
        strncpy(&argv_buf[buf_len],str.toStdString().c_str(),strlen(str.toStdString().c_str()));
        argv[3]=&argv_buf[buf_len];
        buf_len += strlen(str.toStdString().c_str());
        argv_buf[buf_len] = '\0';
        buf_len+=1;
        argv[4] = "ctrlmode";
        argv[5] = "triple-sampling";
        argv[6] = "on";
        argv[7] = NULL;
        argc = 7;

    }else if(strcmp(opt,"ctrlmodeoff")==0)
    {
        argv[0] = "canconfig";
        //argv[1] = (char *)ui->can_file->text().toStdString().c_str();
        str = ui->can_file->text();
        strList= str.split(" ",QString::SkipEmptyParts);
        str = strList[0];
        strncpy(&argv_buf[buf_len],str.toStdString().c_str(),strlen(str.toStdString().c_str()));
        argv[1]=&argv_buf[buf_len];
        buf_len += strlen(str.toStdString().c_str());
        argv_buf[buf_len] = '\0';
        buf_len+=1;
        argv[2] = "bitrate";
       // argv[3] = (char *)ui->can_bitrate->text().toStdString().c_str();
        str = ui->can_bitrate->text();
        strList= str.split(" ",QString::SkipEmptyParts);
        str = strList[0];
        strncpy(&argv_buf[buf_len],str.toStdString().c_str(),strlen(str.toStdString().c_str()));
        argv[3]=&argv_buf[buf_len];
        buf_len += strlen(str.toStdString().c_str());
        argv_buf[buf_len] = '\0';
        buf_len+=1;
        argv[4] = "ctrlmode";
        argv[5] = "triple-sampling";
        argv[6] = "off";
        argv[7] = NULL;
        argc = 7;

    }else if(strcmp(opt,"restart")==0)
    {
        argv[0] = "canconfig";
      //  argv[1] = (char *)ui->can_file->text().toStdString().c_str();
        str = ui->can_file->text();
        strList= str.split(" ",QString::SkipEmptyParts);
        str = strList[0];
        strncpy(&argv_buf[buf_len],str.toStdString().c_str(),strlen(str.toStdString().c_str()));
        argv[1]=&argv_buf[buf_len];
        buf_len += strlen(str.toStdString().c_str());
        argv_buf[buf_len] = '\0';
        buf_len+=1;
        argv[2] = "restart";
        argv[3] = NULL;
        argc = 3;

    }else if(strcmp(opt,"start")==0)
    {
        argv[0] = "canconfig";
       // argv[1] = (char *)ui->can_file->text().toStdString().c_str();
        str = ui->can_file->text();
        strList= str.split(" ",QString::SkipEmptyParts);
        str = strList[0];
        strncpy(&argv_buf[buf_len],str.toStdString().c_str(),strlen(str.toStdString().c_str()));
        argv[1]=&argv_buf[buf_len];
        buf_len += strlen(str.toStdString().c_str());
        argv_buf[buf_len] = '\0';
        buf_len+=1;
        argv[2] = "start";
        argv[3] = NULL;
        argc = 3;

    }else if(strcmp(opt,"stop")==0)
    {
        argv[0] = "canconfig";
       // argv[1] = (char *)ui->can_file->text().toStdString().c_str();
        str = ui->can_file->text();
        strList= str.split(" ",QString::SkipEmptyParts);
        str = strList[0];
        strncpy(&argv_buf[buf_len],str.toStdString().c_str(),strlen(str.toStdString().c_str()));
        argv[1]=&argv_buf[buf_len];
        buf_len += strlen(str.toStdString().c_str());
        argv_buf[buf_len] = '\0';
        buf_len+=1;
        argv[2] = "stop";
        argv[3] = NULL;
        argc = 3;

    }else if(strcmp(opt,"help")==0)
    {
        argv[0] = "canconfig";
       // argv[1] = (char *)ui->can_file->text().toStdString().c_str();
        argv[1] = "--help";
        argv[2] = NULL;
        argc = 2;

    } else if(strcmp(opt,"restart-ms")==0)
    {
        ui->canconfig_errmsg->append("The landlord is lazy, the function is not developed...Please select customcommand to deal with");
        return ;
    }else if(strcmp(opt,"clockfreq")==0)
    {
        ui->canconfig_errmsg->append("The landlord is lazy, the function is not developed...Please select customcommand to deal with");
        return ;
    }else if(strcmp(opt,"bittiming-constants")==0)
    {
        ui->canconfig_errmsg->append("The landlord is lazy, the function is not developed...Please select customcommand to deal with");
        return ;
    }else if(strcmp(opt,"berr-counter")==0)
    {
        ui->canconfig_errmsg->append("The landlord is lazy, the function is not developed...Please select customcommand to deal with");
        return ;
    }else if(strcmp(opt,"customcommand")==0)
    {
        if(ui->can_con_cmd->text().isEmpty() == true)
        {
           ui->canconfig_errmsg->append("input your custom command");
            return ;
        }

        bzero(argv_buf,1024);
        str = ui->can_con_cmd->text();
        strList= str.split(" ",QString::SkipEmptyParts);
        argc = strList.count();

        for(i = 0;i<argc;i++)
        {
            str = strList[i];
            strncpy(&argv_buf[buf_len],str.toStdString().c_str(),strlen(str.toStdString().c_str()));
            argv[i]=&argv_buf[buf_len];
            buf_len += strlen(str.toStdString().c_str());
            argv_buf[buf_len] = '\0';
            buf_len+=1;

           // printf("-hhhhhh-%s--%d\n",argv[i],i);
        }
        argv[argc] = NULL;
    }


   // printf("---- canconfig_main----argv[0]=%s--%d-\n",argv[0],argc);
   // printf("---- canconfig_main----argv[1]=%s--%d-\n",argv[1],argc);
  //  printf("---- canconfig_main----argv[2]=%s--%d-\n",argv[2],argc);
   // printf("---- canconfig_main----argv[3]=%s--%d-\n",argv[3],argc);

    canconfig_main(argc, argv,ui);
  //  ui->canconfig_ok_mesg->append("afd;lakf;l");
}
void can_config::hide_show()
{
    //printf("hide_show\n");
    char *opt = (char *)ui->canconfig_opt->currentText().toStdString().c_str();

    if(strcmp(opt,"customcommand") != 0)
    {
        ui->can_lable_cmd->hide();
        ui->can_con_cmd->hide();
    }else
    {
        ui->can_lable_cmd->show();
        ui->can_con_cmd->show();
    }
}
