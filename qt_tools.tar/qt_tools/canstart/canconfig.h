#ifndef __CANCONFIG__
#define __CANCONFIG__
#include "can_setconfig.h"

int canconfig_main(int argc, char *argv[],Ui::can_config *ui);
#endif
