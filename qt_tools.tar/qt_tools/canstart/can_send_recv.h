#ifndef CAN_SEND_H
#define CAN_SEND_H

#include <QWidget>

namespace Ui {
class can_send_recv;
}

class can_send_recv : public QWidget
{
    Q_OBJECT

public:
    explicit can_send_recv(QWidget *parent = 0);
    ~can_send_recv();
signals:void can_sig(int can_nu);

private slots:
    void on_pushButton_clicked();

    void on_can_msg_recv_clicked();

    void on_can_msg_back__clicked();

private:
    Ui::can_send_recv *ui;
};
int can_send_main(int argc, char **argv,Ui::can_send_recv *ui);
#endif // CAN_SEND_H
