#ifndef __CAN__SEND__
#define __CAN__SEND__
#include "can_send_recv.h"

int can_send_main(int argc, char *argv[],Ui::can_send_recv *ui);
#endif
