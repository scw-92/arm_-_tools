#include "canstart.h"
#include "ui_canstart.h"
#include <string.h>
#define CANCONFIG 1
#define CANECHO 2
#define CANSEND 3

canstart::canstart(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::canstart)
{
    ui->setupUi(this);

}

canstart::~canstart()
{
    delete ui;
}

void canstart::on_can_set_clicked()
{
   const char *option = ui->can_option->currentText().toStdString().c_str();
   if(strcmp(option,"canconfig") == 0)
   {
        qt_canconfig = new can_config();
        qt_canconfig->show();
        this->hide();
        connect(qt_canconfig,&can_config::canconfig_sig,this,&canstart::can_sig_deal);
   }else if(strcmp(option,"cansend-recv") == 0)
   {
        qt_can_send_recv = new can_send_recv();
        qt_can_send_recv->show();
        this->hide();
        connect(qt_can_send_recv,&can_send_recv::can_sig,this,&canstart::can_sig_deal);
   }

}
void canstart::can_sig_deal(int can_number)
{
    switch (can_number)
    {
        case CANCONFIG:
            this->show();
            delete(qt_canconfig);
            break;
        case CANSEND:
            this->show();
            delete(qt_can_send_recv);
            break;
    }
}

void canstart::on_can_back_clicked()
{
    emit qt_can_sig(QT_CAN);
}
