#include "can_send_recv.h"
#include "ui_can_send_recv.h"
#include "can_recv.h"
#define CANSEND 3

can_send_recv::can_send_recv(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::can_send_recv)
{
    ui->setupUi(this);
}

can_send_recv::~can_send_recv()
{
    delete ui;
}

void can_send_recv::on_pushButton_clicked()
{
    int argc  = 0;
    int i = 0;
    char *argv[10]={NULL};

    QString str;
    QStringList strList;
    char argv_buf[1024]={0};
    int buf_len = 0;

        if(ui->can_send_cmd_text->text().isEmpty() == true)
        {
           ui->can_send_msg_text->append("input your send command");
            return ;
        }

        bzero(argv_buf,1024);
        str = ui->can_send_cmd_text->text();
        strList= str.split(" ",QString::SkipEmptyParts);
        argc = strList.count();

        for(i = 0;i<argc;i++)
        {
            str = strList[i];
            strncpy(&argv_buf[buf_len],str.toStdString().c_str(),strlen(str.toStdString().c_str()));
            argv[i]=&argv_buf[buf_len];
            buf_len += strlen(str.toStdString().c_str());
            argv_buf[buf_len] = '\0';
            buf_len+=1;

          // printf("-hhhhhh-%s--%d\n",argv[i],i);
        }
        argv[argc] = NULL;



   // printf("---- canconfig_main----argv[0]=%s--%d-\n",argv[0],argc);
   // printf("---- canconfig_main----argv[1]=%s--%d-\n",argv[1],argc);
  //  printf("---- canconfig_main----argv[2]=%s--%d-\n",argv[2],argc);
   // printf("---- canconfig_main----argv[3]=%s--%d-\n",argv[3],argc);
  //  ui->canconfig_ok_mesg->append("afd;lakf;l");


    can_send_main(argc, argv,ui);
}

void can_send_recv::on_can_msg_recv_clicked()
{
    int argc  = 0;
    int i = 0;
    char *argv[10]={NULL};

    QString str;
    QStringList strList;
    char argv_buf[1024]={0};
    int buf_len = 0;

        if(ui->can_recv_cmd_text->text().isEmpty()  == true)
        {
           ui->can_recv_msg_text->append("input your send command");
            return ;
        }

        bzero(argv_buf,1024);
        str = ui->can_recv_cmd_text->text();
        strList= str.split(" ",QString::SkipEmptyParts);
        argc = strList.count();

        for(i = 0;i<argc;i++)
        {
            str = strList[i];
            strncpy(&argv_buf[buf_len],str.toStdString().c_str(),strlen(str.toStdString().c_str()));
            argv[i]=&argv_buf[buf_len];
            buf_len += strlen(str.toStdString().c_str());
            argv_buf[buf_len] = '\0';
            buf_len+=1;

          // printf("-hhhhhh-%s--%d\n",argv[i],i);
        }
        argv[argc] = NULL;



  //  printf("---- canconfig_main----argv[0]=%s--%d-\n",argv[0],argc);
  //  printf("---- canconfig_main----argv[1]=%s--%d-\n",argv[1],argc);
  //  printf("---- canconfig_main----argv[2]=%s--%d-\n",argv[2],argc);
  //  printf("---- canconfig_main----argv[3]=%s--%d-\n",argv[3],argc);


    can_recv_main(argc, argv,ui);
}

void can_send_recv::on_can_msg_back__clicked()
{
   emit can_sig(CANSEND);
}
