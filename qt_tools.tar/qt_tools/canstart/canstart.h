#ifndef CANSTART_H
#define CANSTART_H

#include <QWidget>
#include "can_setconfig.h"
#include "can_send_recv.h"
#define QT_CAN 3
namespace Ui {
class canstart;
}

class canstart : public QWidget
{
    Q_OBJECT

public:
    explicit canstart(QWidget *parent = 0);
    ~canstart();
    void can_sig_deal(int can_number);
signals:void qt_can_sig(int can_nu);
private slots:
    void on_can_set_clicked();

    void on_can_back_clicked();

private:
    Ui::canstart *ui;
    can_config  *qt_canconfig;
    can_send_recv *qt_can_send_recv;

};

#endif // CANSTART_H
