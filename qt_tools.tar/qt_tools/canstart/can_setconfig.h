#ifndef CAN_CONFIG_H
#define CAN_CONFIG_H

#include <QWidget>

namespace Ui {
class can_config;
}

class can_config : public QWidget
{
    Q_OBJECT

public:
    explicit can_config(QWidget *parent = 0);
    ~can_config();
    void hide_show();
signals:void canconfig_sig(int can_number);

private slots:
    void on_canconfig_back_clicked();

    void on_canconfig_ok_clicked();

private:
    Ui::can_config *ui;
};

#endif // CAN_CONFIG_H
