#ifndef __EEPROM__WR
#define __EEPROM__WR
#include "eeprom.h"
#define QT_EEPROM  4
int eeprom_main(int argc,char *argv[],Ui::eeprom *ui);
#endif
