#include "eeprom.h"
#include "ui_eeprom.h"
#include "eeprom_write_read.h"

eeprom::eeprom(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::eeprom)
{
    ui->setupUi(this);
}

eeprom::~eeprom()
{
    delete ui;
}

void eeprom::on_eeprom_read_clicked()
{

    int argc  = 0;
    int i = 0;
    char *argv[10]={NULL};

    QString str;
    QStringList strList;
    char argv_buf[1024]={0};
    int buf_len = 0;

        if(ui->eeprom_read_cmd->text().isEmpty()  == true)
        {
           ui->eeprom_read_text->append("input your send command");
            return ;
        }

        bzero(argv_buf,1024);
        str = ui->eeprom_read_cmd->text();
        strList= str.split(" ",QString::SkipEmptyParts);
        argc = strList.count();

        for(i = 0;i<argc;i++)
        {
            str = strList[i];
            strncpy(&argv_buf[buf_len],str.toStdString().c_str(),strlen(str.toStdString().c_str()));
            argv[i]=&argv_buf[buf_len];
            buf_len += strlen(str.toStdString().c_str());
            argv_buf[buf_len] = '\0';
            buf_len+=1;

          // printf("-hhhhhh-%s--%d\n",argv[i],i);
        }
        argv[argc] = NULL;



   // printf("---- canconfig_main----argv[0]=%s--%d-\n",argv[0],argc);
   // printf("---- canconfig_main----argv[1]=%s--%d-\n",argv[1],argc);
  //  printf("---- canconfig_main----argv[2]=%s--%d-\n",argv[2],argc);
   // printf("---- canconfig_main----argv[3]=%s--%d-\n",argv[3],argc);
  //  ui->canconfig_ok_mesg->append("afd;lakf;l");
    eeprom_main(argc,argv,ui);

}

void eeprom::on_eeprom_back_clicked()
{
    emit eeprom_sig(QT_EEPROM);
}

void eeprom::on_eeprom_write_clicked()
{
    int argc  = 0;
    int i = 0;
    char *argv[10]={NULL};

    QString str;
    QStringList strList;
    char argv_buf[1024]={0};
    int buf_len = 0;

        if(ui->eeprom_write_cmd->text().isEmpty()  == true)
        {
           ui->eeprom_write_text->append("input your send command");
            return ;
        }

        bzero(argv_buf,1024);
        str = ui->eeprom_write_cmd->text();
        strList= str.split(" ",QString::SkipEmptyParts);
        argc = strList.count();

        for(i = 0;i<argc;i++)
        {
            str = strList[i];
            strncpy(&argv_buf[buf_len],str.toStdString().c_str(),strlen(str.toStdString().c_str()));
            argv[i]=&argv_buf[buf_len];
            buf_len += strlen(str.toStdString().c_str());
            argv_buf[buf_len] = '\0';
            buf_len+=1;

          // printf("-hhhhhh-%s--%d\n",argv[i],i);
        }
        argv[argc] = NULL;



   // printf("---- canconfig_main----argv[0]=%s--%d-\n",argv[0],argc);
   // printf("---- canconfig_main----argv[1]=%s--%d-\n",argv[1],argc);
  //  printf("---- canconfig_main----argv[2]=%s--%d-\n",argv[2],argc);
   // printf("---- canconfig_main----argv[3]=%s--%d-\n",argv[3],argc);
  //  ui->canconfig_ok_mesg->append("afd;lakf;l");
    eeprom_main(argc,argv,ui);
}
