#ifndef EEPROM_H
#define EEPROM_H

#include <QWidget>

namespace Ui {
class eeprom;
}

class eeprom : public QWidget
{
    Q_OBJECT

public:
    explicit eeprom(QWidget *parent = 0);
    ~eeprom();
signals:void eeprom_sig(int eeprom_nu);

private slots:
    void on_eeprom_read_clicked();

    void on_eeprom_back_clicked();

    void on_eeprom_write_clicked();

private:
    Ui::eeprom *ui;
};

#endif // EEPROM_H
