#include "eeprom.h"
#include <QApplication>
#include"eeprom_write_read.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    eeprom w;
    w.show();
    return a.exec();
}
