#include "qt_tools.h"
#include "ui_qt_tools.h"

qt_tools::qt_tools(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::qt_tools)
{
    ui->setupUi(this);


}

qt_tools::~qt_tools()
{
    delete ui;
}

void qt_tools::on_qt_uart_clicked()
{
    qt_uart = new uart();
    qt_uart->show();
    this->hide();
    connect(qt_uart,&uart::qt_uart_sig,this,&qt_tools::qt_tools_deal);
}
void qt_tools::qt_tools_deal(int id )
{

    switch(id)
    {
        case QT_UART:
            qt_uart->hide();
            this->show();
            delete(qt_uart);
            break;
        case QT_RTC:
            qt_rtc->hide();
            this->show();
            delete(qt_rtc);
            break;
        case QT_CAN:
            qt_canstart->hide();
            this->show();
            delete(qt_canstart);
            break;
        case QT_EEPROM:
            qt_eeprom->hide();
            this->show();
            delete(qt_eeprom);
            break;
        case QT_GPIO:
            qt_gpio->hide();
            this->show();
            delete(qt_gpio);
            break;
         default:
            break;

    }
}

void qt_tools::on_qt_rtc_clicked()
{
      qt_rtc = new rtc();
      qt_rtc->show();
      this->hide();
      connect(qt_rtc,&rtc::qt_rtc_sig,this,&qt_tools::qt_tools_deal);
}


void qt_tools::on_qt_can_clicked()
{
    qt_canstart = new canstart();
    qt_canstart->show();
    this->hide();
    connect(qt_canstart,&canstart::qt_can_sig,this,&qt_tools::qt_tools_deal);
}

void qt_tools::on_qt_eeprom_clicked()
{
    qt_eeprom= new eeprom();
    qt_eeprom->show();
    this->hide();
    connect(qt_eeprom,&eeprom::eeprom_sig,this,&qt_tools::qt_tools_deal);
}

void qt_tools::on_pushButton_clicked()
{
    qt_gpio= new gpio();
    qt_gpio->show();
    this->hide();
    connect(qt_gpio,&gpio::qt_gpio_sig,this,&qt_tools::qt_tools_deal);
}
