#include "qt_tools.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    qt_tools w;
    w.show();

    return a.exec();
}
