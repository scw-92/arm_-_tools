#ifndef GPIO_H
#define GPIO_H

#include <QWidget>

namespace Ui {
class gpio;
}

class gpio : public QWidget
{
    Q_OBJECT

public:
    explicit gpio(QWidget *parent = 0);
    ~gpio();
signals:void qt_gpio_sig(int gpio_nu);

private slots:

    void on_gpio_set_clicked();

    void on_gpio_get_clicked();

    void on_gpio_back_clicked();

private:
    Ui::gpio *ui;
};

#endif // GPIO_H
