#ifndef __GPIO__MIAN__
#define __GPIO__MAIN__
#include "gpio.h"
#define QT_GPIO 5
#define GPIO_WRITE 0
#define GPIO_READ 1
#define GPIO_OUT 0
#define GPIO_IN 1
#define GPIO_GET 0
#define GPIO_SET 1
#define GPIO_LOW 0
#define GPIO_HIGH 1
#define GPIO_EXPORT 0
#define GPIO_UNEXPORT 1
#define GPIO_NULL 2
    int gpio_main(int gpio_nu, int gpio_get_set,  int export_or_un,int gpio_out_in,int gpio_value,Ui::gpio *ui);
#endif
