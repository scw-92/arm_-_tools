#include <stdio.h>
#include <string.h>
#include "gpio_main.h"
#include "ui_gpio.h"


int gpio_main(int gpio_nu, int gpio_get_set,  int export_or_un,int gpio_out_in,int gpio_value,Ui::gpio *ui);

int gpio_main(int gpio_nu, int gpio_get_set,  int export_or_un,int gpio_out_in,int gpio_value,Ui::gpio *ui)
{
    FILE *fp;
    char gpio_rw_buf[20] = {0};
    char gpio_direction_path[50] = {0};
    char gpio_value_path[50] = {0};
    int value = 0;
    int readCnt = -1;
//ui->gpio_debug->append("please select export");
//printf("please select export\n!!!");

 /*       if(export_or_un ==GPIO_UNEXPORT)
        {
           if(gpio_get_set != GPIO_NULL)
           {
               printf("please select gpio_set_get null!!!\n");
               ui->gpio_debug->append("please select gpio_set_get null");
               return -1;
           }else
           {
            if ((fp = fopen("/sys/class/gpio/unexport", "w")) == NULL)
                {
                    printf("Cannot open unexport file.\n");
                    ui->gpio_debug->append("Cannot open unexport file");

                }else
                 {

                    printf("open export file success\n");
                    ui->gpio_debug->append("open export file success");
                    fprintf(fp, "%d", gpio_nu);
                    fclose(fp);
                    fp = NULL;
                }
            return 0;
           }
        }

*/
    switch(gpio_get_set)
    {
        case  GPIO_SET:

loop:
            if ((fp = fopen("/sys/class/gpio/export", "w")) == NULL)
                {
                    printf("Cannot open export file.file is exit\n");
                    ui->gpio_debug->append("Cannot open export file.file is exit");
                }else
                 {

                    printf("open export file success\n");
                    ui->gpio_debug->append("open export file success");
                    fprintf(fp, "%d", gpio_nu);
                    fclose(fp);
                    fp = NULL;
                }

            sprintf(gpio_direction_path,"/sys/class/gpio/gpio%d/direction",gpio_nu);
               if ((fp = fopen(gpio_direction_path, "rb+")) == NULL)
               {
                   printf("Cannot open %s.\n",gpio_direction_path);
                   ui->gpio_debug->append("Cannot open:");
                   ui->gpio_debug->append(gpio_direction_path);
                   goto loop;
               }
               if(gpio_out_in==GPIO_OUT)
               {
                    fprintf(fp, "out");
                    ui->gpio_debug->append("direction file write ok(out)");
                    fclose(fp);
                    fp = NULL;
               }else
               {
                   fprintf(fp, "in");
                    ui->gpio_debug->append("direction file write ok(in)");
                   fclose(fp);
                   fp = NULL;
               }


               sprintf(gpio_value_path,"/sys/class/gpio/gpio%d/value",gpio_nu);

                   if ((fp = fopen(gpio_value_path, "rb+")) == NULL)
                   {
                       printf("Cannot open %s.\n",gpio_value_path);
                       ui->gpio_debug->append("Cannot open:");
                       ui->gpio_debug->append(gpio_value_path);
                       return -1;
                   }
                   if(gpio_value == GPIO_HIGH)
                   {
                         strcpy(gpio_rw_buf,"1");
                         fwrite(gpio_rw_buf, sizeof(char), 1, fp);
                          ui->gpio_debug->append("value-ile write ok(1)");
                         fclose(fp);
                         fp = NULL;
                   }else
                   {
                       strcpy(gpio_rw_buf,"0");
                       fwrite(gpio_rw_buf, sizeof(char), 1, fp);
                       ui->gpio_debug->append("value-ile write ok(0)");
                       fclose(fp);
                       fp = NULL;
                   }
            break;
         case GPIO_GET:
               sprintf(gpio_direction_path,"/sys/class/gpio/gpio%d/direction",gpio_nu);
               if ((fp = fopen(gpio_direction_path, "r")) == NULL)
               {
                   printf("Cannot open %s.\n",gpio_direction_path);
                   ui->gpio_debug->append("Cannot open:");
                   ui->gpio_debug->append(gpio_direction_path);
                   return -1;
               }else
               {
                   bzero(gpio_rw_buf,sizeof(gpio_rw_buf));
                   readCnt = fread(gpio_rw_buf,1,sizeof(gpio_rw_buf),fp);
                   if(readCnt<0)
                   {
                       printf("direction file read failed\n");
                       ui->gpio_debug->append("direction file read failed");
                       return -1;
                   }
                   ui->gpio_debug->append("direction file value:");
                   ui->gpio_debug->append(gpio_rw_buf);
                   fclose(fp);
                   fp = NULL;

               }
               sprintf(gpio_value_path,"/sys/class/gpio/gpio%d/value",gpio_nu);

                   if ((fp = fopen(gpio_value_path, "r")) == NULL)
                   {
                       printf("Cannot open %s.\n",gpio_value_path);
                       ui->gpio_debug->append("Cannot open:");
                       ui->gpio_debug->append(gpio_value_path);
                       return -1;
                   }else
                   {
                       bzero(gpio_rw_buf,sizeof(gpio_rw_buf));
                       readCnt = fread(gpio_rw_buf,1,sizeof(gpio_rw_buf),fp);
                       if(readCnt<0)
                       {
                           printf("value file read failed\n");
                           ui->gpio_debug->append("value file read failed");
                           return -1;
                       }
                       ui->gpio_debug->append("value file value:");
                       ui->gpio_debug->append(gpio_rw_buf);
                       fclose(fp);
                       fp = NULL;

                   }

            break;


    }
}
