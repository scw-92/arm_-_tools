#include "gpio.h"
#include "ui_gpio.h"
#include "gpio_main.h"



gpio::gpio(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::gpio)
{
    ui->setupUi(this);
}

gpio::~gpio()
{
    delete ui;
}

void gpio::on_gpio_set_clicked()
{
    int gpio_nu;
    int gpio_get_set;
    int export_or_un;
    int gpio_out_in;
    int gpio_value;
    
    gpio_nu = ui->gpio_number->text().toInt();
    
    if(strcmp(ui->gpio_export->currentText().toStdString().c_str(),"NULL") == 0)
    {
        export_or_un = GPIO_NULL;
    }else if(strcmp(ui->gpio_export->currentText().toStdString().c_str(),"export") == 0)
    {
        export_or_un = GPIO_EXPORT;
    }else 
    {
        export_or_un = GPIO_UNEXPORT;
    }
    
     if (strcmp(ui->gpio_set_get->currentText().toStdString().c_str(),"set")!=0)
    {
        ui->gpio_debug->append("please select set");
        return ;
    }
     gpio_get_set= GPIO_SET;
    
    gpio_value = ui->gpio_value->currentText().toInt();


    
    if(strcmp(ui->gpio_out_in->currentText().toStdString().c_str(),"out")==0)
    {
        gpio_out_in = GPIO_OUT;
    }else
    {
        gpio_out_in= GPIO_IN;
    }
    
    gpio_main(gpio_nu, gpio_get_set,  export_or_un,gpio_out_in,gpio_value,ui);

}

void gpio::on_gpio_get_clicked()
{
    int gpio_nu;
    int gpio_get_set;
    int export_or_un;
    int gpio_out_in;
    int gpio_value;
  //  ui->gpio_debug->append("start");

    gpio_nu = ui->gpio_number->text().toInt();

    if(strcmp(ui->gpio_export->currentText().toStdString().c_str(),"NULL") == 0)
    {
        export_or_un = GPIO_NULL;
    }else if(strcmp(ui->gpio_export->currentText().toStdString().c_str(),"export") == 0)
    {
        export_or_un = GPIO_EXPORT;
    }else
    {
        export_or_un = GPIO_UNEXPORT;
    }

     if (strcmp(ui->gpio_set_get->currentText().toStdString().c_str(),"get")!=0)
    {
        ui->gpio_debug->append("plesae select get");
        return;
    }
    gpio_get_set= GPIO_GET;
    gpio_value = ui->gpio_value->currentText().toInt();



    if(strcmp(ui->gpio_out_in->currentText().toStdString().c_str(),"out")==0)
    {
        gpio_out_in = GPIO_OUT;
    }else
    {
        gpio_out_in= GPIO_IN;
    }
    gpio_main(gpio_nu, gpio_get_set,  export_or_un,gpio_out_in,gpio_value,ui);
   // ui->gpio_debug->append("END");


}

void gpio::on_gpio_back_clicked()
{
    emit qt_gpio_sig(QT_GPIO);
}
