#ifndef QT_TOOLS_H
#define QT_TOOLS_H

#include <QWidget>
#include "uart/uart.h"
#include "qt_rtc/rtc.h"
#include "canstart/canstart.h"
#include "eeprom/eeprom.h"
#include "gpio/gpio.h"

#define QT_UART 1
#define QT_RTC  2
#define QT_CAN 3
#define QT_EEPROM 4
#define QT_GPIO 5
namespace Ui {
class qt_tools;
}

class qt_tools : public QWidget
{
    Q_OBJECT

public:
    explicit qt_tools(QWidget *parent = 0);
    ~qt_tools();
    void qt_tools_deal(int);

private slots:
    void on_qt_uart_clicked();

    void on_qt_rtc_clicked();

    void on_qt_can_clicked();

    void on_qt_eeprom_clicked();

    void on_pushButton_clicked();

private:
    Ui::qt_tools *ui;
    uart *qt_uart;
    rtc *qt_rtc;
    canstart *qt_canstart;
    eeprom *qt_eeprom;
    gpio *qt_gpio;
};

#endif // QT_TOOLS_H
