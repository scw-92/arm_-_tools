#ifndef UART_H
#define UART_H
#define QT_UART 1
#include <QWidget>

namespace Ui {
class uart;
}

class uart : public QWidget
{
    Q_OBJECT

public:
    explicit uart(QWidget *parent = 0);
    ~uart();
    signals:
        void qt_uart_sig(int);

private slots:
    void on_uart_send_clicked();

    void on_uatr_on_clicked();

    void on_uart_off_clicked();

    void on_uart_recv_clicked();

    void on_back_home_clicked();

private:
    Ui::uart *ui;
};

#endif // UART_H
