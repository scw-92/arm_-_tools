#include "rtc.h"
#include "ui_rtc.h"
#include <QString>

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <linux/rtc.h>
#include <sys/ioctl.h>
#include <sys/time.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
//#include <errno.h>

#define RTC_SET 1
#define RTC_UP  0
int fd = -1;
int ui_start =0;
pthread_t pthread_1=0;
int rtc_pthread_flags = 0;




int  rtc_get(  struct rtc_time *rtc_tm , const char *rtc ,Ui::rtc *ui,int);
int rtc_set(  struct rtc_time *rtc_tm , Ui::rtc ui );
int  rtc_pthread_get( struct rtc_time *rtc_tm ,  const char *rtc,Ui::rtc *ui);
int rtc_main(int , const char * ,int &,int&,int&,int&,int&,int&,Ui::rtc *);
int my_close(int);

int my_close(int fd)
{
   return  close(fd);
}
void* pthread_fun(void * arg)
{
    Ui::rtc *ui = (Ui::rtc *)arg;
    struct rtc_time rtc_tm;
    while(rtc_pthread_flags)
    {
        rtc_get(&rtc_tm,ui->rtc_file->text().toStdString().c_str(),ui,RTC_UP);
        sleep(1);

    }
}

int  rtc_get( struct rtc_time *rtc_tm ,  const char *rtc ,Ui::rtc *ui,int rtc_switch)
{
    int retval;
    char buf[30]={0};    
    bzero(buf,30);
    if(fd<0)
    {
         fd = open(rtc, O_RDWR);
        if (fd ==  -1) {
             ui->rtc_msgbox->setText("rtc_open failed");
            return -1;
        }
    }
    /* Read the RTC time/date */
    retval = ioctl(fd, RTC_RD_TIME, rtc_tm);
    if (retval == -1) {
        ui->rtc_msgbox->setText("rtc_get fialed");
        return -1;
    }
        ui->rtc_msgbox->setText("rtc_get ok");

        if(rtc_switch == RTC_UP)
        {
           rtc_tm->tm_hour += 8;//转化为我国时区
           if (rtc_tm->tm_hour >= 24) {
                rtc_tm->tm_sec %= 24;
                rtc_tm->tm_mday++;
             }
          if (rtc_tm->tm_mday >= 31) {
                rtc_tm->tm_mday %= 31;
                rtc_tm->tm_mon++;
          }
          if (rtc_tm->tm_mon >= 12) {
                rtc_tm->tm_mon %= 12;
                rtc_tm->tm_year++;
           }

          if(ui_start)
          {
              ui_start =0;
              QDateTime dt(QDate (rtc_tm->tm_year + 1900,rtc_tm->tm_mon + 1,rtc_tm->tm_mday ),QTime ( rtc_tm->tm_hour,rtc_tm->tm_min ,rtc_tm->tm_sec,0 ));
              ui->set_date_rtc->setDateTime(dt);
          }
         sprintf(buf ,"%d-%02d-%02dT%02d:%02d:%02d",rtc_tm->tm_year + 1900,rtc_tm->tm_mon + 1,rtc_tm->tm_mday,rtc_tm->tm_hour,rtc_tm->tm_min,rtc_tm->tm_sec);
         ui->update_date_rtc->setText(buf);
        }


    return  0;
}




int rtc_set( struct rtc_time *rtc_tm  ,Ui::rtc *ui)
{
          rtc_tm->tm_hour -= 8;
          if (rtc_tm->tm_hour >= 24) {
                  rtc_tm->tm_sec %= 24;
                  rtc_tm->tm_mday++;
          }
          if (rtc_tm->tm_mday >= 31) {
                  rtc_tm->tm_mday %= 31;
                  rtc_tm->tm_mon++;
          }
          if (rtc_tm->tm_mon >= 12) {
                  rtc_tm->tm_mon %= 12;
                  rtc_tm->tm_year++;
          }

    return ioctl(fd,RTC_SET_TIME, rtc_tm);
}

int rtc_main(int rtc_switch, const char *file,int &year,int &month,int &day,int &hour,int &minute,int &second,Ui::rtc *ui)
{
    struct rtc_time rtc_tm;
    const char *rtc = file;
    memset(&rtc_tm,0,sizeof(rtc_tm));

    switch (rtc_switch)
    {
    case RTC_SET:
        rtc_get(&rtc_tm,rtc,ui,RTC_SET);
        rtc_tm.tm_year=year-1900;
        rtc_tm.tm_mon=month-1;
        rtc_tm.tm_mday=day;
        rtc_tm.tm_hour=hour;
        rtc_tm.tm_min=minute;
        rtc_tm.tm_sec=second;
    if(	rtc_set(&rtc_tm,ui)<0)
        {
            ui->rtc_msgbox->setText("rtc_set  failed");
            return -1;
        }
        ui->rtc_msgbox->setText("rtc_set  ok");
/*
        if(fd>0)
        {
            close(fd);
            fd = -1;
        }
        */

        if(rtc_get(&rtc_tm,rtc,ui,RTC_UP)<0)
        {
              ui->rtc_msgbox->setText("rtc_get failed");
              return -1;
        }
        ui->rtc_msgbox->setText("rtc_get ok");
       /* if(fd>0)
        {
            close(fd);
            fd = -1;
        }
        */
        break;
        /* FALLTHROUGH */
    case RTC_UP:
        if(rtc_get(&rtc_tm,rtc,ui,RTC_UP)<0)
        {
              ui->rtc_msgbox->setText("rtc_get failed");
              return -1;
        }
        ui->rtc_msgbox->setText("rtc_get ok");
      /*  if(fd>0)
        {
            close(fd);
            fd = -1;
        }
        */
        break;
    default:
        //fprintf(stderr, "usage:  rtctest [rtcdev]\n");
        return -1;
    }
    return 0;
}



rtc::rtc(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::rtc)
{
    ui->setupUi(this);
    ui_start=1;
    struct rtc_time rtc_tm;
    rtc_get(&rtc_tm,ui->rtc_file->text().toStdString().c_str(),ui,RTC_UP);


    rtc_pthread_flags=1;

loop:
    if(  pthread_create(&pthread_1, NULL, pthread_fun, (void *)ui ) != 0)
        {
            ui->rtc_msgbox->setText("pthread_create failed");
            goto loop;
        }
    else
    {
        ui->rtc_msgbox->setText("pthread_create is ok");
    }

}

rtc::~rtc()
{
    delete ui;
    rtc_pthread_flags=0;
    while(pthread_1)
    {
        if(pthread_1)
        {
            pthread_join(pthread_1,NULL);
            pthread_1 = 0;
        }
    }
    my_close(fd);
    fd = -1;
    ui_start =0;
}

/*
QDate::QDate ( int y, int m, int d )

构造一个年、月、日分别为y、m、d的日期。
y必须在1752－8000之间，m必须在1－12之间，d必须在1－31之间。例外，如果y在0－99之间，它表示的是1900－1999。

QTime::QTime ( int h, int m, int s = 0, int ms = 0 )

构造一个时、分、秒和毫秒分别为h、m、s和ms的时间。
h必须在0－23之间，m和s必须在0－59之间，ms必须在0－999之间。


*/
void rtc::on_update_rtc_clicked()
{
   int year,month,day,hour,minute,second;//这几个变量相当于占位符，没有实际意义

   rtc_main(RTC_UP,ui->rtc_file->text().toStdString().c_str(),year,day,month,hour,minute,second,ui);

}

void rtc::on_set_rtc_clicked()
{
    int year,month,day,hour,minute,second;
    ui->set_date_rtc->date().getDate(&year,&month,&day);

    hour = ui->set_date_rtc->time().hour();
    minute =  ui->set_date_rtc->time().minute();
    second =  ui->set_date_rtc->time().second();
    rtc_main(RTC_SET,ui->rtc_file->text().toStdString().c_str(),year,day,month,hour,minute,second,ui);
}

void rtc::on_back_home_clicked()
{
    emit qt_rtc_sig(QT_RTC);
}
