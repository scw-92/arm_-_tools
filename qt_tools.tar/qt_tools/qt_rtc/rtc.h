#ifndef RTC_H
#define RTC_H

#include <QWidget>
#define QT_RTC 2
namespace Ui {
class rtc;
}

class rtc : public QWidget
{
    Q_OBJECT

public:
    explicit rtc(QWidget *parent = 0);
    ~rtc();
    signals:
        void qt_rtc_sig(int);

private slots:
    void on_update_rtc_clicked();

    void on_set_rtc_clicked();

    void on_back_home_clicked();

private:
    Ui::rtc *ui;
};

#endif // RTC_H
